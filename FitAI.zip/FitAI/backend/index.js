// /backend/index.js
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { GoogleGenerativeAI } from '@google/generative-ai';
import AWS from 'aws-sdk';
import uploadPhotoRoute from './routes/upload-profile-photo.js';
import userProfileRoute from './routes/user-profile-photo.js';



dotenv.config();

const app = express();
const PORT = process.env.PORT || 5001;

// ✅ FIXED CORS Configuration
app.use(cors({
  origin: [
    'http://localhost:3000',
    'https://1f55d0c7-3f22-4e9a-b0da-85af774011b6.preview.emergentagent.com',
    /\.preview\.emergentagent\.com$/
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-requested-with'],
  optionsSuccessStatus: 200
}));

app.use(express.json());
app.use('/api', uploadPhotoRoute);
app.use('/api', userProfileRoute);



// Debug middleware to log all requests
app.use((req, res, next) => {
  console.log(`📝 ${new Date().toISOString()} - ${req.method} ${req.url}`);
  console.log('📝 Origin:', req.get('Origin'));
  console.log('📝 Headers:', req.headers);
  next();
});

// Setup Gemini model
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

// Setup AWS SDK for DynamoDB
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION || 'us-east-1',
});
const dynamoDB = new AWS.DynamoDB.DocumentClient();

// Advanced nutrition calculator
const calculateNutrition = (age, weight, height, activityLevel, goal) => {
  const heightInM = height / 100;
  const bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
  
  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    very_active: 1.9
  };
  
  const tdee = bmr * (activityMultipliers[activityLevel] || 1.55);
  
  let calories;
  switch(goal) {
    case 'fat loss':
      calories = Math.round(tdee - 500);
      break;
    case 'muscle gain':
      calories = Math.round(tdee + 300);
      break;
    case 'maintenance':
      calories = Math.round(tdee);
      break;
    default:
      calories = Math.round(tdee);
  }
  
  return {
    bmr: Math.round(bmr),
    tdee: Math.round(tdee),
    calories,
    protein: Math.round(weight * 2.2), // 2.2g per kg
    carbs: Math.round(calories * 0.45 / 4), // 45% of calories
    fats: Math.round(calories * 0.25 / 9) // 25% of calories
  };
};

// POST: Generate and save ADVANCED diet plan
app.post('/api/generate-diet-plan', async (req, res) => {
  const { 
    email, 
    age, 
    weight, 
    height, 
    activityLevel, 
    goal,
    dietaryRestrictions = [],
    healthConditions = [],
    foodPreferences = [],
    mealCount = 6,
    cuisinePreference = 'mixed'
  } = req.body;

  if (!email || !age || !weight || !height || !activityLevel || !goal) {
    return res.status(400).json({ success: false, message: 'Missing required fields.' });
  }

  try {
    console.log('🔄 Generating advanced diet plan for:', email);
    
    const nutrition = calculateNutrition(age, weight, height, activityLevel, goal);
    
    const advancedPrompt = `
You are Dr. Sarah Chen, a world-renowned nutritionist and sports scientist with 15+ years of experience. You specialize in creating personalized, science-based nutrition plans that deliver real results.

CLIENT PROFILE:
- Age: ${age} years
- Weight: ${weight} kg
- Height: ${height} cm
- Activity Level: ${activityLevel}
- Primary Goal: ${goal}
- Dietary Restrictions: ${dietaryRestrictions.join(', ') || 'None'}
- Health Conditions: ${healthConditions.join(', ') || 'None'}
- Food Preferences: ${foodPreferences.join(', ') || 'None'}
- Preferred Cuisine: ${cuisinePreference}
- Meal Frequency: ${mealCount} meals/day

CALCULATED NUTRITION TARGETS:
- BMR: ${nutrition.bmr} kcal
- TDEE: ${nutrition.tdee} kcal
- Target Calories: ${nutrition.calories} kcal
- Protein: ${nutrition.protein}g
- Carbohydrates: ${nutrition.carbs}g
- Fats: ${nutrition.fats}g

TASK: Create an advanced, personalized 7-day nutrition plan with the following specifications:

1. MEAL PLANNING EXCELLENCE:
   - Each meal should be precisely calculated for macros
   - Include cooking methods and prep techniques
   - Provide portion sizes in grams/cups
   - Add nutritional benefits for each ingredient

2. YOUTUBE RECIPE INTEGRATION:
   - Find REAL, working YouTube recipe links for each meal
   - Prioritize channels with high ratings and clear instructions
   - Include cooking difficulty level (1-5 scale)
   - Estimate preparation and cooking time

3. ADVANCED FEATURES:
   - Weekly shopping list with quantities
   - Meal prep instructions for busy days
   - Alternative options for each meal
   - Hydration schedule with timing
   - Supplement recommendations (if needed)

4. SMART OPTIMIZATION:
   - Pre/post workout nutrition timing
   - Metabolic boosting food combinations
   - Anti-inflammatory ingredients
   - Digestive health considerations

FORMAT (Return strictly valid JSON):

{
  "personalizedInsights": {
    "metabolicType": "string",
    "keyRecommendations": ["string"],
    "expectedResults": "string",
    "timelineToResults": "string"
  },
  "nutritionTargets": {
    "calories": ${nutrition.calories},
    "protein": "${nutrition.protein}g",
    "carbs": "${nutrition.carbs}g",
    "fats": "${nutrition.fats}g",
    "fiber": "string",
    "sugar": "string"
  },
  "weeklyPlan": {
    "monday": [
      {
        "meal": "Breakfast",
        "time": "8:00 AM",
        "name": "Meal Name",
        "description": "Detailed description with cooking method",
        "ingredients": ["ingredient 1", "ingredient 2"],
        "portions": "portion sizes",
        "macros": {
          "calories": number,
          "protein": "number g",
          "carbs": "number g",
          "fats": "number g"
        },
        "recipeLink": "https://youtube.com/watch?v=REAL_VIDEO_ID",
        "cookingTime": "number minutes",
        "difficulty": number,
        "nutritionalBenefits": ["benefit 1", "benefit 2"],
        "alternatives": ["alternative 1", "alternative 2"]
      }
    ],
    "tuesday": [...],
    "wednesday": [...],
    "thursday": [...],
    "friday": [...],
    "saturday": [...],
    "sunday": [...]
  },
  "hydrationPlan": {
    "dailyWaterIntake": "string",
    "timing": ["morning: amount", "afternoon: amount"],
    "additionalFluids": ["green tea", "coconut water"]
  },
  "supplementation": {
    "recommended": ["supplement 1", "supplement 2"],
    "timing": "when to take",
    "benefits": "why needed"
  },
  "mealPrep": {
    "sunday": ["prep task 1", "prep task 2"],
    "wednesday": ["mid-week prep tasks"]
  },
  "shoppingList": {
    "proteins": ["item: quantity"],
    "vegetables": ["item: quantity"],
    "fruits": ["item: quantity"],
    "grains": ["item: quantity"],
    "dairy": ["item: quantity"],
    "others": ["item: quantity"]
  },
  "exerciseNutrition": {
    "preWorkout": {
      "meal": "what to eat",
      "timing": "when to eat",
      "benefits": "why"
    },
    "postWorkout": {
      "meal": "what to eat",
      "timing": "when to eat",
      "benefits": "why"
    }
  },
  "healthTips": [
    "Advanced tip 1 with scientific backing",
    "Advanced tip 2 with practical application",
    "Advanced tip 3 with long-term benefits"
  ],
  "progressTracking": {
    "dailyChecks": ["energy levels", "hunger patterns"],
    "weeklyMeasurements": ["weight", "body fat %"],
    "monthlyGoals": ["specific targets"]
  }
}

CRITICAL REQUIREMENTS:
- Use REAL YouTube recipe links from popular cooking channels
- Ensure all macros add up correctly
- Include Indian/local cuisine options when appropriate
- Make it practical and achievable
- Focus on whole foods and minimal processing
- Return ONLY valid JSON (no markdown, no explanations)
`;

    const chat = model.startChat({ 
      history: [],
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 8192,
      }
    });
    
    const result = await chat.sendMessage(advancedPrompt);
    const text = result.response.text();

    console.log('\n💬 Gemini raw response length:', text.length);

    // Enhanced JSON parsing with better error handling
    let jsonPart = text;
    
    // Try to extract JSON from various markdown formats
    const jsonMatches = text.match(/```json\s*([\s\S]*?)```/) || 
                       text.match(/```\s*([\s\S]*?)```/) ||
                       text.match(/\{[\s\S]*\}/);
    
    if (jsonMatches) {
      jsonPart = jsonMatches[1] || jsonMatches[0];
    }
    
    // Clean up the JSON
    jsonPart = jsonPart.trim();

    let plan;
    try {
      plan = JSON.parse(jsonPart);
      
      // Validate and enhance the plan
      if (!plan.nutritionTargets) {
        plan.nutritionTargets = {
          calories: nutrition.calories,
          protein: `${nutrition.protein}g`,
          carbs: `${nutrition.carbs}g`,
          fats: `${nutrition.fats}g`
        };
      }
      
      // Add client info to the plan
      plan.clientInfo = {
        email,
        age,
        weight,
        height,
        activityLevel,
        goal,
        generatedAt: new Date().toISOString(),
        planId: `diet_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      };
      
      console.log('✅ Successfully parsed advanced diet plan');
      
    } catch (err) {
      console.error('❌ Failed to parse Gemini JSON:', err);
      console.error('Raw response sample:', text.substring(0, 500));
      
      // Fallback plan generation
      plan = {
        nutritionTargets: {
          calories: nutrition.calories,
          protein: `${nutrition.protein}g`,
          carbs: `${nutrition.carbs}g`,
          fats: `${nutrition.fats}g`
        },
        personalizedInsights: {
          metabolicType: "Balanced",
          keyRecommendations: ["Focus on whole foods", "Stay hydrated", "Regular meal timing"],
          expectedResults: `Based on your ${goal} goal, expect gradual progress over 4-6 weeks`,
          timelineToResults: "4-6 weeks"
        },
        weeklyPlan: {
          monday: [
            {
              meal: "Breakfast",
              time: "8:00 AM",
              name: "Protein Oatmeal",
              description: "Oats with protein powder and fruits",
              macros: { calories: 350, protein: "25g", carbs: "45g", fats: "8g" },
              recipeLink: "https://youtube.com/watch?v=dQw4w9WgXcQ",
              cookingTime: "10 minutes",
              difficulty: 2
            }
          ]
        },
        healthTips: ["Stay consistent with meal timing", "Drink water before meals", "Include variety in your diet"],
        clientInfo: { email, age, weight, height, activityLevel, goal }
      };
    }

    // Save to DynamoDB
    const timestamp = new Date().toISOString();
    await dynamoDB.put({
      TableName: 'DietPlans',
      Item: {
        email,
        createdAt: timestamp,
        plan,
      },
    }).promise();

    console.log('✅ Diet plan saved to DynamoDB');

    return res.status(200).json({ 
      success: true, 
      plan,
      calculatedNutrition: nutrition,
      timestamp: new Date().toISOString()
    });

  } catch (err) {
    console.error('❌ Error generating advanced diet plan:', err);
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to generate advanced diet plan. Please try again.',
      error: err.message 
    });
  }
});

// GET: Fetch diet plan history
app.get('/api/diet-history/:email', async (req, res) => {
  const { email } = req.params;

  try {
    const result = await dynamoDB.query({
      TableName: 'DietPlans',
      KeyConditionExpression: 'email = :e',
      ExpressionAttributeValues: {
        ':e': email
      },
      ScanIndexForward: false
    }).promise();

    res.status(200).json({ success: true, history: result.Items });
  } catch (err) {
    console.error('❌ Error fetching history:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch history' });
  }
});

// Additional endpoint for nutrition analysis
app.post('/api/analyze-nutrition', async (req, res) => {
  const { age, weight, height, activityLevel, goal } = req.body;
  
  try {
    const nutrition = calculateNutrition(age, weight, height, activityLevel, goal);
    const analysis = {
      ...nutrition,
      bmi: (weight / Math.pow(height / 100, 2)).toFixed(1),
      recommendations: [],
      metabolicAge: age // Simplified calculation
    };
    
    // Add BMI category
    if (analysis.bmi < 18.5) analysis.bmiCategory = 'Underweight';
    else if (analysis.bmi < 25) analysis.bmiCategory = 'Normal';
    else if (analysis.bmi < 30) analysis.bmiCategory = 'Overweight';
    else analysis.bmiCategory = 'Obese';
    
    res.json({ success: true, analysis });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Analysis failed' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Advanced Diet Plan Server running on http://localhost:${PORT}`);
  console.log(`🔑 Gemini API Key configured: ${process.env.GEMINI_API_KEY ? 'Yes' : 'No'}`);
});