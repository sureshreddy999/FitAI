// /backend/routes/generate-diet-plan.js
import express from 'express';
import { GoogleGenerativeAI } from '@google/generative-ai';
import dotenv from 'dotenv';

dotenv.config();
const router = express.Router();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || 'AIzaSyBADz1cqfqkz2-SlizFOixR5R0hXXoWe5c');
const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

// Advanced nutrition calculator
const calculateNutrition = (age, weight, height, activityLevel, goal) => {
  const heightInM = height / 100;
  const bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
  
  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    very_active: 1.9
  };
  
  const tdee = bmr * (activityMultipliers[activityLevel] || 1.55);
  
  let calories;
  switch(goal) {
    case 'fat loss':
      calories = Math.round(tdee - 500);
      break;
    case 'muscle gain':
      calories = Math.round(tdee + 300);
      break;
    case 'maintenance':
      calories = Math.round(tdee);
      break;
    default:
      calories = Math.round(tdee);
  }
  
  return {
    bmr: Math.round(bmr),
    tdee: Math.round(tdee),
    calories,
    protein: Math.round(weight * 2.2), // 2.2g per kg
    carbs: Math.round(calories * 0.45 / 4), // 45% of calories
    fats: Math.round(calories * 0.25 / 9) // 25% of calories
  };
};

// Advanced meal timing optimizer
const optimizeMealTiming = (goal, activityLevel) => {
  const timings = {
    'fat loss': {
      breakfast: '7:00 AM',
      midMorning: '10:00 AM',
      lunch: '1:00 PM',
      afternoon: '4:00 PM',
      dinner: '7:00 PM',
      evening: '9:00 PM'
    },
    'muscle gain': {
      breakfast: '7:00 AM',
      midMorning: '10:00 AM',
      lunch: '1:00 PM',
      preworkout: '4:00 PM',
      postworkout: '6:00 PM',
      dinner: '8:00 PM',
      bedtime: '10:00 PM'
    },
    'maintenance': {
      breakfast: '8:00 AM',
      lunch: '1:00 PM',
      snack: '4:00 PM',
      dinner: '7:30 PM'
    }
  };
  
  return timings[goal] || timings['maintenance'];
};

router.post('/generate-diet-plan', async (req, res) => {
    const { 
      email, 
      age, 
      weight, 
      height, 
      activityLevel, 
      goal,
      dietaryRestrictions = [],
      healthConditions = [],
      foodPreferences = [],
      mealCount = 6,
      cuisinePreference = 'mixed',
      day = 'monday'  // ✅ NEW: default to monday if not specified
    } = req.body;
  
    if (!email || !age || !weight || !height || !activityLevel || !goal) {
      return res.status(400).json({ success: false, message: 'Missing required fields.' });
    }
  
    try {
      const nutrition = calculateNutrition(age, weight, height, activityLevel, goal);
  
      const prompt = `
  You are Dr. Sarah Chen, a world-renowned nutritionist.
  
  CLIENT INFO:
  Age: ${age}, Weight: ${weight}kg, Height: ${height}cm
  Activity Level: ${activityLevel}, Goal: ${goal}
  Dietary Restrictions: ${dietaryRestrictions.join(', ') || 'None'}
  Health Conditions: ${healthConditions.join(', ') || 'None'}
  Food Preferences: ${foodPreferences.join(', ') || 'None'}
  Cuisine: ${cuisinePreference}, Meals/Day: ${mealCount}
  
  NUTRITION TARGETS:
  Calories: ${nutrition.calories}, Protein: ${nutrition.protein}g, Carbs: ${nutrition.carbs}g, Fats: ${nutrition.fats}g
  
  TASK:
  Generate a diet plan for the day: **${day.toUpperCase()}**
  Include:
  - ${mealCount} meals
  - Meal name, description, ingredients, macros, YouTube recipe link
  
  FORMAT (JSON only):
  {
    "day": "${day}",
    "meals": [...],
    "nutritionTargets": {
      "calories": ${nutrition.calories},
      "protein": "${nutrition.protein}g",
      "carbs": "${nutrition.carbs}g",
      "fats": "${nutrition.fats}g"
    }
  }`;
  
      const chat = model.startChat({
        history: [],
        generationConfig: { temperature: 0.7, topK: 40, topP: 0.95, maxOutputTokens: 8192 }
      });
  
      const result = await chat.sendMessage(prompt);
      const text = result.response.text();
      const jsonMatch = text.match(/```json[\s\S]*?```/) || text.match(/\{[\s\S]*\}/);
      const jsonText = jsonMatch ? jsonMatch[0].replace(/```json|```/g, '').trim() : text;
  
      let plan;
      try {
        plan = JSON.parse(jsonText);
      } catch (err) {
        return res.status(500).json({ success: false, message: 'Failed to parse plan', raw: text });
      }
  
      plan.clientInfo = { email, age, weight, height, activityLevel, goal };
      return res.status(200).json({ success: true, plan });
  
    } catch (err) {
      return res.status(500).json({ success: false, message: 'Failed to generate plan', error: err.message });
    }
  });
  

// Additional endpoint for nutrition analysis
router.post('/analyze-nutrition', async (req, res) => {
  const { age, weight, height, activityLevel, goal } = req.body;
  
  try {
    const nutrition = calculateNutrition(age, weight, height, activityLevel, goal);
    const analysis = {
      ...nutrition,
      bmi: (weight / Math.pow(height / 100, 2)).toFixed(1),
      recommendations: [],
      metabolicAge: age // Simplified calculation
    };
    
    // Add BMI category
    if (analysis.bmi < 18.5) analysis.bmiCategory = 'Underweight';
    else if (analysis.bmi < 25) analysis.bmiCategory = 'Normal';
    else if (analysis.bmi < 30) analysis.bmiCategory = 'Overweight';
    else analysis.bmiCategory = 'Obese';
    
    res.json({ success: true, analysis });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Analysis failed' });
  }
});

export default router;